import geopandas as gpd
import requests
import json
from shapely.geometry import Point

# 1. Funkce pro načtení geografických dat okresů z OpenStreetMap pomocí overpass API
def fetch_districts_from_osm():
    overpass_url = "http://overpass-api.de/api/interpreter"
    overpass_query = """
    [out:json];
    relation["admin_level"="6"]["boundary"="administrative"]["name"];
    out body;
    >;
    out skel qt;
    """
    response = requests.get(overpass_url, params={'data': overpass_query})
    data = response.json()
    
    return data

# 2. Zpracování načtených dat a vytvoření GeoDataFrame
def process_osm_data(osm_data):
    elements = osm_data['elements']
    polygons = []
    names = []
    
    for element in elements:
        if 'tags' in element and 'name' in element['tags']:
            name = element['tags']['name']
            if 'geometry' in element:
                geometry = Point([(point['lon'], point['lat']) for point in element['geometry']])
                polygons.append(geometry)
                names.append(name)
    
    # Vytvoření GeoDataFrame
    gdf = gpd.GeoDataFrame({'name': names, 'geometry': polygons}, crs="EPSG:4326")
    return gdf

# 3. Načtení existujícího JSON souboru
def load_existing_json(json_file_path):
    with open(json_file_path, 'r', encoding='utf-8') as f:
        districts_data = json.load(f)
    return districts_data

# 4. Aktualizace JSON souboru o souřadnice
def update_json_with_coordinates(gdf, districts_data):
    for index, row in gdf.iterrows():
        district_name = row['name']
        centroid = row['geometry'].centroid
        if district_name in districts_data:
            districts_data[district_name]['coords'] = [centroid.x, centroid.y]
    
    return districts_data

# 5. Uložení aktualizovaného JSON souboru
def save_updated_json(districts_data, output_file_path):
    with open(output_file_path, 'w', encoding='utf-8') as f:
        json.dump(districts_data, f, ensure_ascii=False, indent=4)

# Hlavní funkce
def main(json_file_path):
    # Načti OSM data
    osm_data = fetch_districts_from_osm()
    
    # Zpracuj OSM data do GeoDataFrame
    gdf = process_osm_data(osm_data)
    
    # Načti existující JSON soubor
    districts_data = load_existing_json(json_file_path)
    
    # Aktualizuj JSON data o souřadnice
    updated_data = update_json_with_coordinates(gdf, districts_data)
    
    # Ulož aktualizovaný JSON
    output_file_path = 'updated_districts_data_with_coords.json'
    save_updated_json(updated_data, output_file_path)
    print(f"Aktualizovaná data byla uložena do {output_file_path}")

# Spuštění hlavní funkce
json_file_path = 'C:/Users/maxmi/OneDrive/Dokumenty/asdasd/districts_data.json'
main(json_file_path)
